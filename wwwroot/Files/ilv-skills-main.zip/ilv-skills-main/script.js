// Object to track chakra counts for each skill
const chakraCounts = {
    demolisher: 0,
    druglord: 0,
    infiltrator: 0
};

// Function to handle adding chakras
function addChakra(skill) {
    if (chakraCounts[skill] < 5) { // Limit to 5 chakras
        chakraCounts[skill]++;
        updateChakraDisplay(skill);
        
        // Optionally send the updated count to the Lua script via NUI callback
        fetch(`https://${GetParentResourceName()}/addChakra`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ skill: skill, count: chakraCounts[skill] })
        });
    }

    // If max chakras reached (5), close the UI (optional)
    if (chakraCounts[skill] === 5) {
        fetch(`https://${GetParentResourceName()}/closeUI`, {
            method: 'POST'
        });
    }
}

// Function to update the chakra display
function updateChakraDisplay(skill) {
    const card = document.querySelector(`.card:has(h2.${skill})`);
    const dots = card.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        if (index < chakraCounts[skill]) {
            dot.classList.add('filled');
        } else {
            dot.classList.remove('filled');
        }
    });
}

// Listen for messages from Lua to show the UI
window.addEventListener('message', (event) => {
    if (event.data.type === 'showUI') {
        document.body.style.display = 'block';
    }
});